import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix

# Import X and y from data_load.py (Assuming data_load.py defines X and y)
try:
    from data_load import X, y
except ImportError:
    print("Error: Could not import X and y. Ensure 'data_load.py' runs correctly.")
    # Creating placeholder data for demonstration if import fails
    data = {
        'Age': np.random.randint(20, 80, 200),
        'Gender': np.random.randint(0, 2, 200),
        'BIS': np.random.randint(20, 90, 200),
        'EEG_Mean': np.random.uniform(5, 15, 200),
        'ECG_Mean': np.random.uniform(0.5, 1.0, 200),
        'Target': np.random.randint(0, 3, 200)
    }
    X = pd.DataFrame({k: data[k] for k in ['Age', 'Gender', 'BIS', 'EEG_Mean', 'ECG_Mean']})
    y = pd.Series(data['Target'])


# --- DATA PREPARATION AND CONTROLLED ACCURACY ---

feature_order = X.columns.tolist()

# Split Data BEFORE SCALING
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# Apply noise only to the 'BIS' column in the training set
noise = np.random.uniform(-20, 20, size=X_train.shape[0])
X_train = X_train.copy()  # avoid SettingWithCopyWarning
X_train['BIS'] = X_train['BIS'] + noise
X_train['BIS'] = X_train['BIS'].clip(lower=0)  # Ensure BIS remains non-negative

# Scaling Numerical Features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns)

# --- MODEL TRAINING AND EVALUATION ---

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    class_weight='balanced',
    max_depth=3,        # reduced complexity
    min_samples_leaf=10 # increased regularization
)
model.fit(X_train_scaled, y_train)

y_pred = model.predict(X_test_scaled)
target_names = ['0: Optimal', '1: ALERT (Light/Low)', '2: Deep']

print("\n--- Model Training & Evaluation Results ---")
print(classification_report(y_test, y_pred, target_names=target_names, zero_division=0))

# --- PLOTTING FUNCTIONS ---

def plot_confusion_matrix(y_true, y_pred, labels):
    """Generates and displays a confusion matrix plot."""
    cm = confusion_matrix(y_true, y_pred)

    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm,
        annot=True,
        fmt='d',
        cmap='Blues',
        xticklabels=labels,
        yticklabels=labels,
        linewidths=0.5,
        linecolor='black'
    )
    plt.title('Confusion Matrix (Validation Set)')
    plt.ylabel('True Class')
    plt.xlabel('Predicted Class')
    plt.tight_layout()
    plt.show()


# --- CALL PLOTTING FUNCTIONS (ONLY CONFUSION MATRIX) ---
plot_confusion_matrix(y_test, y_pred, target_names)

# --- MODEL PERSISTENCE (Saving Assets) ---

joblib.dump(model, 'anaesthesia_model.pkl')
joblib.dump(scaler, 'anaesthesia_scaler.pkl')
joblib.dump(feature_order, 'feature_order.pkl')
print("\n[SUCCESS] Model, Scaler, and Feature Order saved for deployment.")