# anaesthesia_monitor.py

import tkinter as tk
from tkinter import font as tkfont
import joblib
import pandas as pd
from deployment_logic import deploy_alert_system # Import your core logic

# --- CONFIGURATION ---
MODEL_FILE = 'anaesthesia_model.pkl'
SCALER_FILE = 'anaesthesia_scaler.pkl'
FEATURES_FILE = 'feature_order.pkl'

# --- 1. LOAD SAVED ASSETS ---
try:
    loaded_model = joblib.load(MODEL_FILE)
    loaded_scaler = joblib.load(SCALER_FILE)
    loaded_feature_order = joblib.load(FEATURES_FILE)
    print("Deployment assets loaded successfully.")
except FileNotFoundError:
    print(f"ERROR: Model assets not found. Please run train_model.py first.")
    exit()

# --- 2. SIMULATION DATA (The data point that triggers the alert) ---
NEW_PATIENT_DATA = {
    'Age': 35,
    'Gender': 'Male',
    'BIS': 55, # High BIS to force the ALERT state
    'EEG_Channel_1': 12.0, 'EEG_Channel_2': 10.5, 'EEG_Channel_3': 11.2, 
    'ECG_Channel_1': 0.7, 'ECG_Channel_2': 0.8, 'ECG_Channel_3': 0.75,
}

# --- 3. UI/UX LOGIC ---

class AnaesthesiaMonitor(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold")
        self.alert_font = tkfont.Font(family='Helvetica', size=36, weight="bold")
        self.action_font = tkfont.Font(family='Helvetica', size=16)
        
        self.title("Anaesthesia Alert Monitor (OR View)")
        self.geometry("800x450")
        self.configure(bg='white')
        
        # Initial call to run the simulation logic
        self.run_alert_system()

    def run_alert_system(self):
        """Runs the prediction and updates the UI based on the result."""
        
        final_alert_message = deploy_alert_system(
            new_raw_data=NEW_PATIENT_DATA, 
            model=loaded_model, 
            scaler=loaded_scaler, 
            feature_order=loaded_feature_order
        )
        
        # Split the message into STATUS and ACTION
        if "IMMEDIATE ACTION" in final_alert_message:
            status, action = final_alert_message.split(" - ")
            color = 'red' if 'ALERT' in status else 'orange'
        else:
            status = final_alert_message
            action = "Monitoring"
            color = 'green'

        self.update_ui(status, action, color)

    def create_vitals_frame(self, container):
        """Displays the core input metrics (Vitals Zone)."""
        vitals_frame = tk.Frame(container, bg='#F0F0F0', padx=10, pady=10, relief=tk.GROOVE, borderwidth=2)
        vitals_frame.pack(fill='x', padx=20, pady=10)
        
        tk.Label(vitals_frame, text="CORE VITALS (Input Data)", font=self.title_font, bg='#F0F0F0').grid(row=0, column=0, columnspan=3, pady=5)
        
        # Display BIS
        tk.Label(vitals_frame, text="BIS Score:", font=('Helvetica', 18, 'bold'), bg='#F0F0F0').grid(row=1, column=0, padx=10, sticky='w')
        tk.Label(vitals_frame, text=NEW_PATIENT_DATA['BIS'], font=('Helvetica', 28, 'bold'), fg='darkred', bg='#F0F0F0').grid(row=1, column=1, padx=10, sticky='w')
        
        # Display other key metrics
        key_metrics = [
            ("Age:", NEW_PATIENT_DATA['Age']), 
            ("Gender:", NEW_PATIENT_DATA['Gender']), 
            ("EEG Mean:", round(NEW_PATIENT_DATA['EEG_Channel_1'], 1)), 
        ]
        
        for i, (label, value) in enumerate(key_metrics):
            tk.Label(vitals_frame, text=label, font=('Helvetica', 12), bg='#F0F0F0').grid(row=2 + (i//3), column=(i%3)*2, padx=10, sticky='w')
            tk.Label(vitals_frame, text=value, font=('Helvetica', 12, 'bold'), bg='#F0F0F0').grid(row=2 + (i//3), column=(i%3)*2 + 1, sticky='w')
            
        return vitals_frame

    def update_ui(self, status, action, color):
        """Clears and rebuilds the main UI with new results."""
        # Clear existing widgets
        for widget in self.winfo_children():
            widget.destroy()

        # 1. PRIMARY ALERT ZONE (Dominates the view)
        alert_frame = tk.Frame(self, bg=color, padx=30, pady=30, relief=tk.RAISED)
        alert_frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Status Label (Large and Dominant)
        status_label = tk.Label(alert_frame, text=status, font=self.alert_font, bg=color, fg='white')
        status_label.pack(pady=(10, 5))
        
        # Action Label
        action_label = tk.Label(alert_frame, text=action, font=self.action_font, bg=color, fg='white', wraplength=700)
        action_label.pack(pady=5)
        
        # 2. CORE VITALS ZONE
        self.create_vitals_frame(self)


if __name__ == '__main__':
    # You must have run train_model.py successfully before running this.
    app = AnaesthesiaMonitor()
    app.mainloop()