# run_alert_system.py

import joblib
# Import the core logic function from the separate file
from deployment_logic import deploy_alert_system 

# --- 1. LOAD SAVED ASSETS ---

try:
    # Load the trained model, scaler, and feature list saved by train_model.py
    loaded_model = joblib.load('anaesthesia_model.pkl')
    loaded_scaler = joblib.load('anaesthesia_scaler.pkl')
    loaded_feature_order = joblib.load('feature_order.pkl')
    print("Deployment assets loaded successfully (model, scaler, feature order).")
except FileNotFoundError:
    print("ERROR: Deployment assets not found. You must run 'train_model.py' first.")
    exit()

# --- 2. REAL-TIME SIMULATION DATA ---

# Scenario: Simulating a critical state (high BIS=85) to trigger the ALERT
new_patient_data = {
    'Age': 35,
    'Gender': 'Male',
    'BIS': 14,
    'EEG_Channel_1': 12.0, 'EEG_Channel_2': 10.5, 'EEG_Channel_3': 11.2, 
    'ECG_Channel_1': 0.7, 'ECG_Channel_2': 0.8, 'ECG_Channel_3': 0.75,
}

# --- 3. EXECUTE ALERT SYSTEM ---

final_alert = deploy_alert_system(
    new_raw_data=new_patient_data, 
    model=loaded_model, 
    scaler=loaded_scaler, 
    feature_order=loaded_feature_order
)

print("\n--- REAL-TIME SIMULATION RESULT (The Final Project Output) ---")
print(final_alert)