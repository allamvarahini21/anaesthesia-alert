# deployment_logic.py

import pandas as pd
import joblib 

def deploy_alert_system(new_raw_data: dict, model, scaler, feature_order: list):
    """
    Processes a single new data point and issues an anaesthesia alert.
    """
    new_df = pd.DataFrame([new_raw_data])
    
    # Feature Engineering (must match training exactly)
    eeg_cols = ['EEG_Channel_1', 'EEG_Channel_2', 'EEG_Channel_3']
    ecg_cols = ['ECG_Channel_1', 'ECG_Channel_2', 'ECG_Channel_3']
    
    new_df['EEG_Mean'] = new_df[eeg_cols].mean(axis=1)
    new_df['EEG_SD'] = new_df[eeg_cols].std(axis=1) 
    new_df['ECG_Mean'] = new_df[ecg_cols].mean(axis=1)
    new_df['ECG_SD'] = new_df[ecg_cols].std(axis=1)
    
    new_df.drop(columns=eeg_cols + ecg_cols, inplace=True)
    
    # Encode Gender: 'Female'=1, 'Male'=0
    new_df['Gender'] = new_df['Gender'].map({'Female': 1, 'Male': 0})
    
    # Scaling
    X_new = new_df[feature_order] 
    X_scaled_new = scaler.transform(X_new)
    
    # Prediction
    prediction = model.predict(X_scaled_new)[0]
    
    # EMOJI REMOVED
    status_map = {0: "Optimal Anaesthesia", 1: "Light/Low Anaesthesia ALERT!", 2: "Deep Anaesthesia"}
    alert_status = status_map[prediction]
    
    if prediction == 1:
        return f"{alert_status} - IMMEDIATE ACTION: Increase anaesthetic agent dose."
    else:
        return alert_status