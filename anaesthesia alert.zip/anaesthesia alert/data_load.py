# data_load.py

import pandas as pd
import numpy as np

# --- CONFIGURATION ---
# IMPORTANT: Change the file name to the Excel version and specify the sheet.
FILE_NAME = "ml dataset.xlsx" 

# --- DATA LOADING AND CLEANING ---
try:
    # Use pd.read_excel and specify the sheet name
    df = pd.read_excel(FILE_NAME, sheet_name="Sheet1") 
    print("Dataset loaded successfully from Excel.")
except FileNotFoundError:
    print(f"Error: File '{FILE_NAME}' not found. Did you install 'openpyxl'?")
    exit()
except Exception as e:
    print(f"A reading error occurred: {e}")
    exit()

df_ml = df.copy()

# Drop raw signal columns and irrelevant metadata
eeg_cols_raw = ['EEG_Channel_1', 'EEG_Channel_2', 'EEG_Channel_3']
ecg_cols_raw = ['ECG_Channel_1', 'ECG_Channel_2', 'ECG_Channel_3']
features_to_drop = eeg_cols_raw + ecg_cols_raw + ['Timestamp', 'Patient_ID']

# --- FEATURE ENGINEERING ---

# Signal Aggregation (Mean and SD across channels)
df_ml['EEG_Mean'] = df_ml[eeg_cols_raw].mean(axis=1)
df_ml['EEG_SD'] = df_ml[eeg_cols_raw].std(axis=1)
df_ml['ECG_Mean'] = df_ml[ecg_cols_raw].mean(axis=1)
df_ml['ECG_SD'] = df_ml[ecg_cols_raw].std(axis=1)

df_ml.drop(columns=features_to_drop, inplace=True)

# Categorical Feature Encoding: Gender (Female=1, Male=0)
df_ml['Gender'] = df_ml['Gender'].astype('category').cat.codes

# Target Variable Mapping (The Alert Logic)
def map_anaesthesia_level(level):
    if level in ['D1', 'D2']:
        return 1  # 1: ALERT (Light/Low)
    elif level in ['D3', 'D4']:
        return 0  # 0: OPTIMAL
    elif level in ['D5']:
        return 2  # 2: DEEP
    else:
        return 0

df_ml['Target'] = df_ml['Anaesthesia_Level'].apply(map_anaesthesia_level)
df_ml.drop(columns=['Anaesthesia_Level'], inplace=True)

# Separate Features (X) and Target (y)
X = df_ml.drop(columns=['Target'])
y = df_ml['Target']

print("Data preprocessing complete. X and y datasets are ready.")